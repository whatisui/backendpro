from blue import app
from flask_cors import CORS, cross_origin
cors = CORS(app)
app.run(debug=True,port=1234,host='0.0.0.0')