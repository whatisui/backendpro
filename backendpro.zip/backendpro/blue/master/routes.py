from flask import Blueprint,request
import pymongo
import json
from flask_jwt_extended import (
     jwt_required,
)
chat_client = pymongo.MongoClient("mongodb://localhost:27017/")
chat_db = chat_client["bike"]
mod = Blueprint('master', __name__)

@mod.route('/getStuff')
def getStuff():
	return '{"result" : "You are in Master API!!!"}'

@mod.route("/create",methods=['POST'])
@jwt_required
def insert():
    try:
        collection_col = chat_db['master']
        data = request.get_json(force=True)
        insertVar = collection_col.insert_one(data)
        print(insertVar)
        if insertVar.inserted_id:
            status = True
            msg = "Inserted succcessfully"
        else:
            status = False
            msg = "Insert failed"
        data_center = {
            "status": status ,
            "msg" :  msg,
            "id" : str(insertVar.inserted_id)
        }
        return json.dumps(data_center)
    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return {"status" : "false" ,"msg" : msg }

@mod.route("/read",methods=['GET'])
@jwt_required
def find_collection():
    try:
        collection_col = chat_db['master']
        data_center = []
        for row in collection_col.find():
            row['_id'] = str(row['_id'])
            data_center.append(row)
        return json.dumps(data_center)

    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return {"status": "false","msg": msg }

@mod.route("/update", methods=['POST'])
@jwt_required
def update_collection():
    try:
        collection_col = chat_db['master']
        data = request.get_json()
        query = {"username": data['username']}
        newvalues = {"$set": data}
        collection_col.update_one(query, newvalues)
        for x in collection_col.find():
            if x['_id']:
                msg = "Successfully Updated"
                return {"status": True, "msg": msg}
            else:
                msg = "Update failed"
                return {"status": False, "msg": msg}
    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return {"status": "false","msg": msg }

@mod.route("/delete",methods =['POST'])
@jwt_required
def delete():
    try:
        data = request.get_json()
        collection_col = chat_db['master']
        print(data)
        myquery = {"del_id": data['del_id']}
        deleteVar = collection_col.delete_one(myquery)
        print(deleteVar,deleteVar.deleted_count)
        if deleteVar.deleted_count == 1:
            status = True
            msg = "deleted succcessfully"
        else:
            status =  False
            msg = "deletion failed"
        data_center = {
            "status": status ,
            "msg" :  msg
        }
        return json.dumps(data_center)
    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return {"status": "false" ,"msg": msg }

