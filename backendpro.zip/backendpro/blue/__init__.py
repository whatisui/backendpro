from flask import request, jsonify, Flask
from flask_jwt_extended import (
    JWTManager, jwt_required, create_access_token,
    get_jwt_identity
)
import json
import random
import string
import pymongo
app = Flask(__name__)
app.secret_key = 'bike'
myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["bike"]
mycol = mydb["apps"]
app.config['JWT_SECRET_KEY'] = 'bike'  # Change this!
jwt = JWTManager(app)

@app.route('/login',methods=['POST'])
def login():
    try:
        data = request.get_json()
        x = mycol.find_one({}, {"username": data['username'],"password":data['password']});
        if x["username"] == data['username']:
            print(x)
            access_token = create_access_token(identity=data['username'])
        return json.dumps({"access_token": access_token, "status": True, "user_token":randomStringDigits(10)})
    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return json.dumps({"status" : "false" ,"msg" : msg })

@app.route('/register',methods=['POST'])
def register():
    try:
        data = request.get_json()
        xc = mycol.find_one({}, {"username": data['username']})
        if xc["username"] == data['username']:
            msg = "Username already exists"
            return json.dumps({"status": False, "msg": msg})
        else:
            x = mycol.insert_one(data)
            if x.inserted_id:
                msg = 'Successfully registered.'
                return json.dumps({"status": True,"msg": msg })
            else:
                msg = 'Cannot register.'
                return json.dumps({"status": False, "msg": msg})
    except Exception as err:
        msg = "Exception at '{}'".format(err)
        return json.dumps({"status": "false", "msg": msg})

@app.route('/protected', methods=['GET'])
@jwt_required
def protected():
    current_user = get_jwt_identity();
    return jsonify(user=current_user), 200

from blue.api.routes import mod
from blue.core.routes import mod
from blue.master.routes import mod
from blue.viva.routes import mod
from blue.ride.routes import mod

app.register_blueprint(api.routes.mod, url_prefix='/api')
app.register_blueprint(core.routes.mod, url_prefix='/core')
app.register_blueprint(master.routes.mod, url_prefix='/master')
app.register_blueprint(viva.routes.mod, url_prefix='/viva')
app.register_blueprint(ride.routes.mod, url_prefix='/ride')

def randomStringDigits(stringLength=6):
    """Generate a random string of letters and digits """
    lettersAndDigits = string.ascii_letters + string.digits
    return ''.join(random.choice(lettersAndDigits) for i in range(stringLength))